#!/usr/bin/python
########################################################
# Script Name : Password Changer                       #
# By : HOSSAM                                          #
# Site  : tl4s.com.sa & mtwer.com & linux-op.com       #
########################################################
#
import random, string, os, commands, sys

Max_Count = 15

def genpass():
	chars = string.letters + string.digits
	return ''.join([random.choice(chars) for GEN in range(Max_Count)])

print "\nPut \033[32m[1]\033[0m to change all sites password"
print "Put \033[32m[2]\033[0m to change some of sites password"

while True:
	choose = raw_input("Put your choice : ")
	if choose == "1":
		print '\nAll sites will change their own password\n'
		FILE = open('/etc/domainusers')
		while True:
			list = FILE.readline()
			if len(list) == 0:
				break
			print '='*20
			domain =  'Domain : ' + list.split(":")[1]
			user =  'User   : ' + list.split(":")[0]
			FILE_PASS = open('/root/Pass_Gen', 'w')
			FILE_PASS.write(genpass())
			FILE_PASS.close()
			COM = commands.getoutput("passwd --stdin %s < /root/Pass_Gen" %(list.split(":")[0]))
			OPEN_F_PASS = open('/root/Pass_Gen').readline()
			password = '\nPass   : ' + OPEN_F_PASS + '\n'
			password_file = open("data.txt", "a")
			password_file.write(str(domain))
			password_file.write(str(user))
			password_file.write(password)
			password_file.close()
		break
	elif choose == "2":
		print '\nChange some of sites password\n'
		try:
			SOME_S = open('/root/sites')
		except:
			print "\033[31mPlease put your domains or users in '/root/sites' file\033[0m\n"
			sys.exit()
		FILE = open('/etc/domainusers').read()
		def nl2br(s):
			return ''.join(s.split('\n'))

		while True:
			list = SOME_S.readline()
			if len(list) == 0:
				break
			if nl2br(list) in FILE:
				print '='*20
				domain_com = commands.getoutput("cat /etc/domainusers | grep %s | cut -d':' -f2" %(nl2br(list)))
				print 'Domain :' + '\033[32m',domain_com,'\033[0m'
				user_com = commands.getoutput("cat /etc/domainusers | grep %s | cut -d':' -f1" %(nl2br(list)))
				print 'User   : ' + user_com
				FILE_PASS = open('/root/Pass_Gen', 'w')
				FILE_PASS.write(genpass())
				FILE_PASS.close()
				COM = commands.getoutput("passwd --stdin %s < /root/Pass_Gen" %(user_com))
				OPEN_F_PASS = open('/root/Pass_Gen').readline()
				print 'Pass   : ' + OPEN_F_PASS
		break

	else:
		continue

COM_Syn = commands.getoutput('/scripts/ftpupdate')
print '\n',COM_Syn,'\n'
if os.path.exists('/root/Pass_Gen'):
	os.remove('/root/Pass_Gen')
