#!/usr/bin/python
########################################################
# Script Name : Password Changer                       #
# By : HOSSAM                                          #
# Site  : tl4s.com.sa & mtwer.com & linux-op.com       #
########################################################
#
import shutil, os

DEST = "/usr/local/cpanel/whostmgr/docroot/cgi/"
shutil.copy2("whm_plugin/addon_pass_changer.cgi", DEST)
shutil.copy2("whm_plugin/CK_user.cgi", DEST)
os.chmod("%sCK_user.cgi" %(DEST), 0755)
os.chmod("%saddon_pass_changer.cgi" %(DEST), 0755)
print "\nPassword Changer plugin has been installed..\n"
